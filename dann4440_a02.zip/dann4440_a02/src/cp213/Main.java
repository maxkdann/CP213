package cp213;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		Integer[]g = new Integer[2];
		g[0] = 0;
		g[1]=2;
		Integer[]g2 = new Integer[3];
		g2[0] = 3;
		g2[1] = 5;
		g2[2] = 7;
		Movie movie = new Movie("Dark city", 1998, "Alex Proyas", 7.8, g);
		Movie movie2 = new Movie("Jesus",2002, "kill me",6.9,g2);
		ArrayList<Movie> movies = new ArrayList<>();
		movies.add(movie);
		movies.add(movie2);
		Scanner keyboard = new Scanner(System.in);
		//Movie m =MovieUtilities.getMovie(keyboard);
		//System.out.println(m);
		Integer[]ints = new Integer[3];
		ints[0] = 2;
		ints[1] = 5;
		ints[2] = 7;
		Movie[] films = new Movie[2];
		films[0] = movie;
		films[1] = movie2;
		Movie m = MovieUtilities.getMovie(keyboard);
		System.out.println(m.toString());
		/*
		Integer[] genres = MovieUtilities.readGenres(keyboard);
		for (Integer i:genres) {
			System.out.println(i);
		}
		*/
		//File f = new File("movies.txt");
		//MovieUtilities.writeMovies(f,films);
		/*
		ArrayList<Movie>ms = MovieUtilities.readMovies(f);
		for (Movie w:ms) {
			System.out.println(w.toString());
		}
		*/
		/*
		String input = "Dellamorte Dellamore|1994|Michele Soavi|7.2|3,4,5,8";
		
		Movie yeet = MovieUtilities.readMovie(input);
		System.out.println(yeet.toString());
		*/
		/*
		Integer[] gMovies = MovieUtilities.readGenres(keyboard);
		for(Integer m:gMovies) {
			System.out.println(m);
		}
		*/
		/*
		ArrayList<Movie> gMovies = MovieUtilities.getByYear(movies, 2002);
		for(Movie m:gMovies) {
			System.out.println(m);
		}
		*/
		
		/*
		int []genreCounts = MovieUtilities.genreCounts(movies);
		for (int i:genreCounts) {
			System.out.print(i+" ");
		}
		*/
		//genres string to list testing
		/*
		String s ="2,3,6";
		Integer[] genres = Movie.genresStringToList(s);
		for (int i:genres) {
			System.out.println(i);
		}
		*/
		//menu testing
		/*
		String m =Movie.menu();
		System.out.println(m);
		*/
		//genres list testing
		//Integer [] genres = Movie.getGenres();
		
		//String l = Movie.genresListToNames();
		//System.out.println(l);
		/*
		File file = new File("output.txt");
		PrintStream ps = new PrintStream(file);
		movie.write(ps);
		*/
	}

}
