package cp213;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

/**
 * Utilities for working with Movie objects.
 *
 * @author David Brown
 * @version 2020-10-01
 */
public class MovieUtilities {

    /**
     * Counts the number of movies in each genre given in Movie.GENRES.
     *
     * @param movies
     *            list of movies
     * @return
     */
    public static int[] genreCounts(final ArrayList<Movie> movies) {
    	int counter = 0;
    	int [] counts = new int[movies.get(0).GENRES.length];
    	for (Movie m:movies) {
    		Integer[] genres = m.getGenres();
    		for (int i:genres) {
    			counts[i]++;
    			counter++;
    		}
    	}
    	int[]genreCounts = new int[counter];
    	int tracker = 0;
    	for (int j=0;j<counts.length;j++) {
    		if(counts[j]!=0) {
    			genreCounts[tracker] = counts[j];
    			tracker++;
    		}
    	}
    	ArrayList<Integer> temp = new ArrayList<>();
    	for (int genre:genreCounts) {
    		if(genre!=0) {
    			temp.add(genre);
    		}
    	}
    	int[]finalResult = new int[temp.size()];
    	for(int i=0;i<temp.size();i++) {
    		finalResult[i] = temp.get(i);
    	}
    	return finalResult;
    }

    /**
     * Creates a Movie object by requesting data from a user.
     *
     * @param keyboard
     *            a keyboard Scanner QUESTION THIS
     * @return a Movie object
     */
    public static Movie getMovie(final Scanner keyboard) {

    	System.out.println("Input Title: ");
    	String title = keyboard.nextLine();
    	System.out.println("Input year: ");
    	int year = Integer.parseInt(keyboard.nextLine());
    	System.out.println("Input Director: ");
    	String director = keyboard.nextLine();
    	System.out.println("Rating: ");
    	double rating = Double.parseDouble(keyboard.nextLine());
    	//double rating = 8.0;
    	System.out.println("Genres: ");
    	String[] genres = keyboard.nextLine().split("\\,");
    	
    	Integer[] g = new Integer[genres.length];
    	for (int i =0;i<genres.length;i++) {
    		g[i] = Integer.parseInt(genres[i]);
    	}
    	
    	Movie movie = new Movie(title,year,director,rating,g);
    	return movie;
    }

    /**
     * Creates a list of Movies whose list of genres include genre.
     *
     * @param movies
     *            list of movies
     * @param genre
     *            genre to compare against
     * @return list of movies for genre
     */
    public static ArrayList<Movie> getByGenre(final ArrayList<Movie> movies, final int genre) {
		final ArrayList<Movie> gMovies = new ArrayList<>();
			boolean genresIncludeGenre = false;
	    	for (Movie m:movies) {
	    		
	    		genresIncludeGenre = false;
	    		Integer[] allGenres = m.getGenres();
	    		int i = 0;
	    		while (!genresIncludeGenre&&i<allGenres.length){
	    			if (allGenres[i]==genre) {
	    				genresIncludeGenre = true;
	    				gMovies.add(m);
	    			}
	    			else {
	    				i++;
	    			}
	    		}
	    		
	    	}
	
		return gMovies;
    }

    /**
     * Creates a list of Movies whose list of genres include all the genre codes
     * in genres.
     *
     * @param movies
     *            list of movies
     * @param genres
     *            genres list to compare against
     * @return list of movies for genres
     */
    public static ArrayList<Movie> getByGenres(final ArrayList<Movie> movies,final Integer[] genres) {
		final ArrayList<Movie> gMovies = new ArrayList<>();
		boolean match;
	    for (Movie m:movies) {
	    	match = true;
	    	Integer[] g = m.getGenres();
	    	if (g.length==genres.length) {
		    	for(int i=0;i<g.length;i++) {
		    		if (g[i]!=genres[i]) {
		    			match = false;
		    		}
		    	}
		    	if(match) {
		    		gMovies.add(m);
		    	}
	    	}
	    }
	
		return gMovies;
    }

    /**
     * Creates a list of Movies whose ratings are equal to or higher than
     * rating.
     *
     * @param movies
     *            list of movies
     * @param rating
     *            to compare against
     * @return list of movies for rating
     */
    public static ArrayList<Movie> getByRating(final ArrayList<Movie> movies,final double rating) {
		final ArrayList<Movie> rMovies = new ArrayList<>();
	
	    for (Movie m:movies) {
	    	if(m.getRating()>=rating) {
	    		rMovies.add(m);
	    	}
	    }
	
		return rMovies;
    }

    /**
     * Creates a list of Movies from a particular year.
     *
     * @param movies
     *            list of movies
     * @param year
     *            year to search for
     * @return list of movies for year
     */
    public static ArrayList<Movie> getByYear(final ArrayList<Movie> movies, final int year) {
		final ArrayList<Movie> yMovies = new ArrayList<>();
	
	    for (Movie m:movies) {
	    	if(m.getYear()==year) {
	    		yMovies.add(m);
	    	}
	    }
	
		return yMovies;
    }

    /**
     * Testing.
     *
     * @param args
     *            Unused
     * @throws FileNotFoundException
     */
    public static void main(final String[] args) throws FileNotFoundException {

    // your code here

    }

    /**
     * Asks a user to select genres from a list of genres and returns an integer
     * list of the genres chosen.
     *QUESTION THIS
     * @return
     */
    public static Integer[] readGenres(final Scanner keyboard) {
		final ArrayList<Integer> genres = new ArrayList<>();
		final int n = Movie.GENRES.length;
		int genre = 0;
		System.out.println(Movie.menu());
		System.out.println("Enter a genre number ('q' to quit):");
		while(genres.size()==0||keyboard.hasNext("q")) {
			if(keyboard.hasNextInt()) {
				genre = keyboard.nextInt();
				if (genre<0) {
					System.out.println("Genre code must be greater than 0");
				}
				else if(genre>=n) {
					System.out.println("Genre code must be less than"+n);
				}
				else if (genres.contains(genre)) {
					System.out.println("Genre code already in list");
				}
				else {
					genres.add(genre);
				}
			}
		}
		
		return genres.toArray(new Integer[1]);
    }

    /**
     * Creates and returns a Movie object from a line of formatted string data.
     *
     * @param line
     *            a vertical bar-delimited line of movie data in the format
     *            title|year|director|rating|genres
     * @return the data from line as a Movie object
     */
    public static Movie readMovie(final String line) {
    	char[] chars = line.toCharArray();
    	String[] parts = line.split("\\|");
    	String title = parts[0];
    	int year = Integer.parseInt(parts[1]);
    	String director = parts[2];
    	double rating = Double.parseDouble(parts[3]);
    	char[] nums = parts[4].toCharArray();
    	ArrayList<Integer> genres = new ArrayList<>();
    	for (Character s:nums) {
    		if(Character.isDigit(s)) {
    			genres.add(Integer.parseInt(String.valueOf(s)));
    		}
    	}
    	Integer[] g = new Integer[genres.size()];
    	for (int i = 0;i<genres.size();i++) {
    		g[i] = genres.get(i);
    	}
    	
    	return new Movie(title,year,director,rating,g);
    }

    /**
     * Reads a list of Movies from a file.
     *
     * @param file
     *            The file to read.
     * @return A list of Movie objects.
     * @throws FileNotFoundException
     */
    public static ArrayList<Movie> readMovies(final File file) throws FileNotFoundException {
		final ArrayList<Movie> movies = new ArrayList<>();
	
	    Scanner in = new Scanner(file);
	    while(in.hasNextLine()) {
	    	Movie m = readMovie(in.nextLine());
	    	movies.add(m);
	    	//System.out.println(in.next());
	    }
		return movies;
    }

    /**
     * Writes the contents of movies to fv. Overwrites or creates a new file of
     * Movie objects converted to strings.
     *
     * @param fv
     * @param movies
     * @throws FileNotFoundException
     */
    public static void writeMovies(final File file, final Movie[] movies)throws FileNotFoundException {

		PrintStream ps = new PrintStream(file);
		for (Movie m:movies) {
			m.write(ps);
			ps.append("\n");
		}
		

    }

}
