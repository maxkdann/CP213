package cp213;

/**
 * @author your name here
 * @author David Brown
 * @version 2020-10-16
 */
public class A03Test {

	/**
     * Note that not all the data structure methods are called in this main. The
     * main method is just an illustration of how you may test your code. Test your
     * code thoroughly.
     *
     * When you start, comment out all code in the main, and un-comment as you add
     * code to the class.
     *
     * @param args (unused)
     */
    public static void main(String[] args) {
		final String LINE = new String(new char[40]).replace("\0", "-");
		/*
		// Test SingleStack
		SingleStack<Integer> stack = new SingleStack<>();
		System.out.println(LINE);
		System.out.println("SingleStack");
		System.out.println(stack.peek());
		System.out.println(stack.pop());
		stack.push(0);
		System.out.println(stack.peek());
		stack.push(1);
		stack.push(2);
		System.out.println(stack.peek());
		System.out.println(stack.pop());
		*/
		// Test SingleQueue
		/*
		SingleQueue<Integer> sq = new SingleQueue<>();
		SingleQueue<Integer> sq2 = new SingleQueue<>();
		SingleQueue<Integer> result = new SingleQueue<>();
		
		sq2.insert(18);
		sq2.insert(43);
		sq2.insert(60);
		sq2.insert(69);
		sq2.insert(5);
		
		sq2.split(sq, result);
		while(!sq.isEmpty()) {
			System.out.println(sq.remove());
		}
		System.out.println();
		while(!result.isEmpty()) {
			System.out.println(result.remove());
		}
		*/
		// Test SinglePriorityQueue
		/*
		SinglePriorityQueue<Integer> pq = new SinglePriorityQueue<>();
		System.out.println(pq.remove());
		SinglePriorityQueue<Integer> higher = new SinglePriorityQueue<>();
		SinglePriorityQueue<Integer> lower = new SinglePriorityQueue<>();
		pq.splitByKey(55, higher, lower);
		System.out.println("HIGHER");
		while(!higher.isEmpty()) {
			System.out.println(higher.remove());
		}
		System.out.println("LOWER");
		while(!lower.isEmpty()) {
			System.out.println(lower.remove());
		}
		*/
		
		
		// Test SingleList
		
		SingleList<Integer> list = new SingleList<>();
		
		list.append(1);
		//System.out.println(list.peek());
		list.append(2);
		list.append(3);
		list.append(4);
		
		//list.clean();
		//System.out.println(list.getLength());
		SingleList<Integer> list2 = new SingleList<>();
		SingleList<Integer> list3 = new SingleList<>();
		
		System.out.println(list3.index(299));
		/*
		System.out.println(list.identical(list2));
		for (int i=1;i<=4;i++) {
			list2.append(i);
		}
		System.out.println(list.identical(list2));
		*/
		//System.out.println(list.find(2));
		//System.out.println(list.find(1));
		//list2.append(1);
		//list3.combine(list, list2);
		/*
		System.out.println(list.contains(2));
		System.out.println(list3.contains(45));
		*/
		/*
		while(!list3.isEmpty()) {
			System.out.println(list3.removeFront());
		}
		*/
		
		
    }
	
}